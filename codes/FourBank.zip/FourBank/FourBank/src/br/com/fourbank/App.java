package br.com.fourbank;

import java.sql.Date;

import br.com.fourbank.service.ServicoConta;
import br.com.fourbank.service.ServicoUsuario;
import br.com.fourbank.util.Cliente;

public class App {

	public static void main(String[] args) {
		
		//cadastrarUsuario(u1) ->cria conta no servico
		//cadastrarUsuario(u2)
		
		//autenticar(u1)
		//fazerDeposito(u1, valor)
		
		//autenticar(u2)
		//fazerDeposito(u2, valor)
		
		Date d = new Date(16041997);
		Cliente c = new Cliente("Icaro", "037.407.353.84", d);
		ServicoUsuario.cadastrarUsuario(c);
		
		String login = "icaro";
		String senha = "i123";
		
		float valor = 100;
		String contaDestino = "123654";
		ServicoConta.transferirDinheiro(c, contaDestino, valor);
		
	}
}
