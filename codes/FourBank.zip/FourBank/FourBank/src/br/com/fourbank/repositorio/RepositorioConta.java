package br.com.fourbank.repositorio;

import java.util.HashMap;
import java.util.Map;
import br.com.fourbank.util.Conta;

public class RepositorioConta {

	private Map<Integer, Conta> repositorio = new HashMap<>();

	public void add(int id, Conta c) {
		repositorio.put(id, c);
	}

}
