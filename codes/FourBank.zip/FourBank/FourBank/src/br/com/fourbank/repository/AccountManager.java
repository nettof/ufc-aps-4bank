package br.com.fourbank.repository;

import java.util.ArrayList;
import java.util.List;

import br.com.fourbank.util.Conta;

public class AccountManager {
	
	private List<Conta> lc = new ArrayList<Conta>();
	
	public void add(Conta conta){
		lc.add(conta);
	}

	public List<Conta> getLc() {
		return lc;
	}

	public void setLc(List<Conta> lc) {
		this.lc = lc;
	}
}
