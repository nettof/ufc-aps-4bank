package br.com.fourbank.repository;

import java.util.HashMap;
import java.util.Map;

public class MultiBank {
	
	private Map<Integer, Integer> hm = new HashMap<Integer, Integer>();

	public Map<Integer, Integer> getHm() {
		return hm;
	}

	public void setHm(Map<Integer, Integer> hm) {
		this.hm = hm;
	}
	
	public void add(int codigo, int valor){
		hm.put(codigo, valor);
	}
	
	public boolean containsK(int codigo){
		return hm.containsKey(codigo);
	}
	
	public Integer get(int codigo){
		return hm.get(codigo);
	}
	
	public void delete(Integer codigo){
		hm.remove(codigo);
	}
}
