package br.com.fourbank.service;

import br.com.fourbank.repository.AccountManager;
import br.com.fourbank.util.Conta;

public class ServiceAccountManager {
	AccountManager am = new AccountManager();
	
	public void createAccount(Conta conta){
		//if()
			am.add(conta);
	}
}
