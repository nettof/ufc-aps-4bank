package br.com.fourbank.service;

import java.util.Random;

import br.com.fourbank.repository.MultiBank;
import br.com.fourbank.util.Conta;

public class ServiceMultiBank {
	
	MultiBank mb = new MultiBank();
	
	public int solicitaSaque(int valor) {
		Random rand = new Random();
		int codigo = rand.nextInt(9999999);
		mb.add(codigo, valor);
		return codigo;
	}

	public void realizaSaque(Conta conta, int codigo) {
		if (mb.containsK(codigo)) {
			conta.setSaldo(conta.getSaldo() - mb.get(codigo));
			mb.delete(codigo);
			System.out.println("Retire as notas...");
		}
	}
}
