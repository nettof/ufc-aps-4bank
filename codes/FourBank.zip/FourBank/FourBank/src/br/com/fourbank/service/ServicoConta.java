package br.com.fourbank.service;

import br.com.fourbank.util.Cliente;
import br.com.fourbank.util.Conta;

public class ServicoConta {

	public static void transferirDinheiro(Cliente c, String contaDestino, float valor) {
		
	}

	public static void deposito(Conta co, float valor) {
		co.setSaldo(valor);
	}

}
