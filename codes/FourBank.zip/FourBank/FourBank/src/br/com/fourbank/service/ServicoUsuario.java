package br.com.fourbank.service;

import br.com.fourbank.repositorio.RepositorioCliente;
import br.com.fourbank.repositorio.RepositorioConta;
import br.com.fourbank.util.Cliente;
import br.com.fourbank.util.Conta;

public class ServicoUsuario {

	private static RepositorioCliente repositorioCliente;
	private static RepositorioConta repositorioConta;

	
	public static Cliente autenticar(String login, String senha) {
		Cliente c = repositorioCliente.getClientePorLogin(login);
		if (c != null && c.getSenha().equals(senha))
			return c;
		else
			return null;
	}
	
	public static void cadastrarUsuario(Cliente c){
		repositorioCliente.add(c);
		Conta co = new Conta();
		co.setNumConta(c.getId());
		co.setCliente(c);
		co.setSaldo(0);
		repositorioConta.add(c.getId(), co);
	}
}