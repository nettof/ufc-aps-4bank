package br.com.fourbank.util;

import java.util.Date;

public class Cliente extends Pessoa {
	
	private String senha;
	private int id;

	public Cliente(String nome, String cnpj) {
		super(nome, cnpj);
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nome, String cpf, Date nasc) {
		super(nome, cpf, nasc);
		// TODO Auto-generated constructor stub
	}

	public String getSenha() {
		return senha;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
