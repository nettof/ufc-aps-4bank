package br.com.fourbank.util;

import br.com.fourbank.service.ServiceMultiBank;

public class Saque {
	private Conta conta;
	private int valor;

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	int solicitaSaque() {
		ServiceMultiBank smb = new ServiceMultiBank();
		return smb.solicitaSaque(valor);
	}

}
