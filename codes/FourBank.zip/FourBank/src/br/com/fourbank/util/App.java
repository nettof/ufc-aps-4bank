package br.com.fourbank.util;

public class App {
	public static void main(String[] args) {
		Conta conta;
		Cliente cliente; 
	}
}
