package br.com.fourbank.util;

import java.util.Date;

public class Cliente extends Pessoa {

	public Cliente(String nome, String cnpj) {
		super(nome, cnpj);
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nome, String cpf, Date nasc) {
		super(nome, cpf, nasc);
		// TODO Auto-generated constructor stub
	}

}
