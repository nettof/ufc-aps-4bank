package br.com.fourbank.util;

public class Conta {

	private Cliente cliente;
	private String numConta;
	@SuppressWarnings("unused")
	private int senha;
	private float saldo;

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public String getNumConta() {
		return numConta;
	}

	public void setNumConta(String numConta) {
		this.numConta = numConta;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}

}
