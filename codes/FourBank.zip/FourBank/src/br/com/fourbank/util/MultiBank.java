package br.com.fourbank.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MultiBank {

	private int codigo;
	private Map<Integer, Integer> hm = new HashMap<Integer, Integer>();

	protected int solicitaSaque(int valor) {
		Random rand = new Random();
		this.codigo = rand.nextInt(9999999);
		hm.put(codigo, valor);
		return codigo;
	}

	void realizaSaque(Conta conta, int codigo) {
		if (hm.containsKey(codigo)) {
			conta.setSaldo(conta.getSaldo()-hm.get(codigo));
			hm.remove(codigo);
			System.out.println("Retire as notas...");
		}
	}

	public Map<Integer, Integer> getHm() {
		return hm;
	}

	public void setHm(Map<Integer, Integer> hm) {
		this.hm = hm;
	}
}
