package br.com.fourbank.util;

public class Saque {
	private Conta conta;
	private int valor;

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	int solicitaSaque() {
		MultiBank mb = new MultiBank();
		return mb.solicitaSaque(valor);
	}

}
